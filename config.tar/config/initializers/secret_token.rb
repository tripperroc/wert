# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
GMHS::Application.config.secret_key_base = '313e80f8d48ae9849f1dc6bf8619ace57f99604656223a93d39500b73d995bb4e996e28d78499c937bda90da1dec6149c1268979da8476f70c8dacaf827f29eb'
